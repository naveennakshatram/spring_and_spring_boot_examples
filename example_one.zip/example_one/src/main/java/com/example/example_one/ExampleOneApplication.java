package com.example.example_one;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleOneApplication.class, args);
	}

}
