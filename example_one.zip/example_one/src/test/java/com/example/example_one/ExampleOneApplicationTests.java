package com.example.example_one;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
